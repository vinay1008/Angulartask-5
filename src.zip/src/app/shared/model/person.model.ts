export class Person{
  constructor(public id : string, public firstName : string, public lastName : string, public email: string, public contact : string , public department : string, public username : string, public password : string, public role : string, public leaves : Object | any){}
}