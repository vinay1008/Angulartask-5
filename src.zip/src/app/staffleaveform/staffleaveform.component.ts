import { Component } from '@angular/core';

@Component({
  selector: 'app-staffleaveform',
  templateUrl: './staffleaveform.component.html',
  styleUrls: ['./staffleaveform.component.css']
})
export class StaffleaveformComponent {

}
