export interface LeaveForm {
    department : string;
    fromdate : string
    todate : string;
    name : string;
    noofdays : string;
    reason : string;
    status : string;
  }